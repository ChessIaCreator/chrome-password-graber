# Browser-password-stealer
This python program gets all the saved passwords, credit cards and bookmarks from chromium based browsers supports chromium 80 and above!

# 📎Modules Required
To install all the required modules use the following code:
<br/>
<b>pip install -r requirements.txt</b>

# Supported browsers
## Chromium Based Browsers
    ✔ AVAST Browser
    ✔ Amigo
    ✔ Torch
    ✔ Kometa
    ✔ Orbitum
    ✔ Cent-browser
    ✔ 7star
    ✔ Sputnik
    ✔ Vivaldi
    ✔ Google-chrome-sxs
    ✔ Google-chrome
    ✔ Epic-privacy-browser
    ✔ Microsoft-edge
    ✔ Uran
    ✔ Yandex
    ✔ Brave
    ✔ Iridium


# 💡Copyrights © [Henry Richard J](https://github.com/henry-richard7)

# Install Required Python Packages
pip install -r requirements.txt

# How to Use
Just run this **chromium_based_browsers.py** the code will create a folder based on the browser name and stores the saved passwords, credit cards and bookmarks in that folder.

# 💡Copyrights © [Henry Richard J](https://github.com/henry-richard7)

#### Star the Repo in case you liked it :)
